//
//  ListUnitRow.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//
import SwiftUI

struct ListUnitRow: View {
 let listUnit: ListUnit
 var body: some View {
 HStack {
 Image(listUnit.name)
 .resizable()
 .scaledToFill()
 .frame(width: 80, height: 80)
 .clipped()
 VStack(alignment: .leading) {
 Text(listUnit.name)
    .font(.headline)
 Text(listUnit.content)
    .font(.footnote)
 }
 Spacer()
 }

 }
}

struct ListUnitRow_Previews: PreviewProvider {
 static var previews: some View {
    ListUnitRow(listUnit: ListUnit(base:"test",name: "對的時間點", content: "林俊傑",detail:"testteswt111"))
 .previewLayout(.fixed(width: 300, height: 70))

 }
}
