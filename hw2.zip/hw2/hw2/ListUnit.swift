//
//  MyListUnit.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//

struct ListUnit {
    let base:String
    let name: String
    let content: String
    let detail: String
}
