//
//  GridView.swift
//  hw2
//
//  Created by User10 on 2020/4/14.
//  Copyright © 2020 ntou. All rights reserved.
//

import SwiftUI

struct GridView: View {
    let names = [["螺絲起子  SCREWDRIVER", "柯夢波丹   COSMOPOLITAN"], ["血腥瑪麗  Bloody Mary", "長島冰茶 Long Island Iced Tea"],["瑪格莉特 MARGARITA","琴湯尼Gin Tonic"],[ "自由古巴 Cuba Libre",    "教父 COD FATHER"],["側車 Side Car"]]

    var columnCount = 2
    let photoWidth = (UIScreen.main.bounds.size.width - 10) / 2-10

    var body: some View {
   
        NavigationView {
            List {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                       
                        BigPicView(list:listUnits1)
                        BigPicView(list:listUnits2)
                        BigPicView(list:listUnits3)
                        BigPicView(list:listUnits4)
                        BigPicView(list:listUnits5)
                        BigPicView(list:listUnits6)
                        

                        
                        
                        
                    }
                    .frame(height: 300)
                }
                
                ForEach(names.indices) { (row) in
                    HStack(spacing:10) {
                        ForEach(self.names[row].indices) { (column) in
                            Image(self.names[row][column])
                            .resizable()
                            .scaledToFill()
                            .frame(width: self.photoWidth, height: self.photoWidth)
                            .clipped()
                        }
                    }
                    .padding(.horizontal, 10)
                }
                .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 10, trailing: 0))
            }
            .onAppear {
            UITableView.appearance().separatorColor = .clear}
            .navigationBarTitle("照片牆")
        }
                
        
    }
}

struct GridView_Previews: PreviewProvider {
    static var previews: some View {
        GridView()
    }
}

struct BigPicView: View {
    let list:[ListUnit]
    var body: some View {
        ForEach(self.list.indices) { (item) in
            NavigationLink(destination: ListUnitDetail(listUnit:self.list[item])) {
                
                Image(self.list[item].name)
                    .renderingMode(.original)
                    .resizable()
                    .scaledToFill()
                    .clipped()
                    
            }
        }
    }
}
