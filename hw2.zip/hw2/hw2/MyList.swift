//
//  MyList.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//

import SwiftUI

struct MyList: View {
    var body: some View {
        NavigationView {
            
            List{
                /*Section(header: Text("伏特加 Vodka")) {
                     ForEach(listUnits1.indices) { (item) in
                        NavigationLink(destination: ListUnitDetail(listUnit:listUnits1[item])) {
                            ListUnitRow(listUnit: listUnits1[item])
                        }
                     }
                 }*/
                
                SecView(list:listUnits1)
                SecView(list:listUnits2)
                SecView(list:listUnits3)
                SecView(list:listUnits4)
                SecView(list:listUnits5)
                SecView(list:listUnits6)

                
                
                
            }.navigationBarTitle("經典調酒")
                
        }

    }
}
        
            

        
    


struct MyList_Previews: PreviewProvider {
    static var previews: some View {
        MyList()
    }
}

struct SecView: View {
    
    let list:[ListUnit]
    var body: some View {
        Section(header: Text(list[0].base)) {
            ForEach(list.indices) { (item) in
                NavigationLink(destination: ListUnitDetail(listUnit:self.list[item])) {
                    ListUnitRow(listUnit: self.list[item])
                }
            }
        }
    }
}
