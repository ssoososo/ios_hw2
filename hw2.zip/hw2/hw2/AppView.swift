//
//  AppView.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//
import SwiftUI


struct AppView: View {
    var body: some View {
        TabView {
            MyList()
                .tabItem {
                    Image(systemName: "house")//SF Symbol
                    Text("介紹")
            }
            GridView()
                .tabItem {
                    Image(systemName: "photo")//SF Symbol
                    Text("照片牆")
            }
        }
        .accentColor(.red)
    }
}

struct AppView_Previews: PreviewProvider {
    static var previews: some View {
        AppView()
        //.environment(\.colorScheme, .dark)
    }
}
