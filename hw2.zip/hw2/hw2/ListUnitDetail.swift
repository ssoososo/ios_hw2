//
//  ListUnitDetail.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//

import SwiftUI

struct ListUnitDetail: View {
        @State private var opacity: Double = 0
    let listUnit: ListUnit
     var body: some View {
        List {
             VStack {
                
                 Image(listUnit.name)
                 .resizable()
                 .scaledToFill()
                 .frame( width: 350,height: 300 )
                 .clipped()

                  Text(listUnit.detail)
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
             }
            .opacity(opacity)
            .transition(.opacity) 
            .animation(
                Animation.linear(duration: 1)
                
            )
            .onAppear {
                self.opacity = 1}
             .navigationBarTitle(listUnit.name)
        }
        
    }
}


    struct SongDetail_Previews: PreviewProvider {
     static var previews: some View {
     ListUnitDetail(listUnit: listUnits3[0])
     }
}


